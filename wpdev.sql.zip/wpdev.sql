-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2022 at 08:48 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wpdev`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `tr_name` varchar(255) NOT NULL,
  `tr_email` varchar(255) NOT NULL,
  `tr_address` varchar(255) NOT NULL,
  `tr_num` int(11) NOT NULL,
  `tr_uni` varchar(255) NOT NULL,
  `tr_dob` date NOT NULL DEFAULT current_timestamp(),
  `tr_gender` varchar(255) NOT NULL,
  `tr_img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`tr_name`, `tr_email`, `tr_address`, `tr_num`, `tr_uni`, `tr_dob`, `tr_gender`, `tr_img`) VALUES
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-07', '', ''),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-07', '', ''),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-07', '', ''),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-07', '', ''),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-07', '', ''),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-13', 'male', '1.png'),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-11', 'male', '1.png'),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-04', 'male', '95578379_2544468402533803_4921121979559313408_o.jpg'),
('Mahbubur Rahman', 'rahmanfahim02@gmail.com', 'House No : 57,Road : 01,Avenue Road : 07, Block :G,Banosree,Rampura,Dhaka-1219', 1854893856, 'city university', '2022-04-04', 'male', '95578379_2544468402533803_4921121979559313408_o.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
